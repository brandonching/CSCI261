The Default File Managment System is As Follows
*** ALL DATA FILES MUST BE TAB DELAMINATED

|-- SchedulePlanner.exe
    |-- Data
        |-- CourseCatalog.txt
    |-- Exports 
        |-- [Save Location]