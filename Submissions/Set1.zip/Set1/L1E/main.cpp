/* CSCI 261: Assignment 1: L1E - Makefile Targets
 *
 * Author: Brandon Ching
 * Resources: N/A
 *
 * Description: Hello world main.cpp for first Makefile
 */

// Libraries
#include <iostream>  // For cin, cout, etc.

// Library namespace
using namespace std;

// Constants

int main() {
  cout << "Hello world!" << endl;
  return 0;
}