#ifndef CALCULATOR_FUNCTIONS_H
#define CALCULATOR_FUNCTIONS_H
void print_result(int a, int b, int result, char op);
void print_options();
void add(int a, int b);
void sub(int a, int b);
void mult(int a, int b);
void divide(int a, int b);
void turn_calculator_on();
#endif  