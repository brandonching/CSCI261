1. Which data structure did you choose to implement? (Array or Linked List)
Linked List

2. What challenges did your choice of data structure present when reading the file?
Due to a struggle in reading the file in general i had to use a clunky method of working with and analizing the string of each row to assingn x,y,z and p,q,r. Due to the struggles i was encoutering I would have probaly had the same issues even if i chose to use an Array

3. Does the data structure choice have any effect on the process of reading the file?
No, I would have read the file in the same process even if i used arrays, I would just have assigned the xyz and prq values slighly diffrently

4. How did you build up your lists? Add one element at a time? Or create the full list and set each element one at a time?
Added one element at a time to the linked list

5. What challenges did your choice of data structure present when validating the file?
I didnt have any challenges validating the data in the file, I was able to quickly and easily integrate the validations

6. Does the data structure choice have any effect on the process of validating the file?
Slightly, main diffrence is using an array you can loop through more easily to compare

7. What challenges did your choice of data structure present when printing data from the file?
None, the linkedlist was easy to print from, would be bassically the same as an array, though linked list might be more natural due to it have names for xyz not index 012

8. Does the data structure choice have any effect on the process of printing data from the file?
not really, because i used the at() function i was able to print just like I would have from an array, though I guess the O() would be slower for the linked list as it iterates through every time.
